package com.SpringExample.SpringClass;

public class College {
    public static String collegename(){
        return "you are in student class inside studentname function";
    }
    public String collegebranch(){
        return "you are in student class inside studentname function";
    }
}


