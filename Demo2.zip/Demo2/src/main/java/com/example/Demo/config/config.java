package com.example.Demo.config;

import com.example.Demo.Service.MyService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class config {
    @Bean
    public MyService Myservice(){
        return new MyService();
    }
}
