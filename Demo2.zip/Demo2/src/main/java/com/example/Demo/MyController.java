package com.example.Demo;

import com.example.Demo.Service.MyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyController {
    @Autowired
    MyService Myservice;
    @GetMapping("books")
    public List<Books> books(){
        return Myservice.getBooks();

    }

    @PostMapping("addbook")
    public Books addBook(@RequestBody  Books books){
        return Myservice.addBook(books);
    }

    @GetMapping("bookbyid")
    public Books bookByid(@RequestParam("id") int id){
        return Myservice.getByid(id);
    }

}
