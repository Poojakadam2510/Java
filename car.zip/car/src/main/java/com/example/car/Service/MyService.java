package com.example.car.Service;

import com.example.car.Cars;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MyService implements MyServiceInterface{

    List<Cars> list = new ArrayList<Cars>();
    public MyService(){
        list.add( new Cars(1,"xyz","about xyz"));
        list.add( new Cars(2,"abc","about abc"));
    }

    @Override
    public List<Cars> getCars() {
        return list;
    }


    @Override
    public Cars addCars(Cars cars) {
        this.list.add(cars);
        return cars;
    }

    @Override
    public Cars getByid(int id) {
        for (Cars cars:this.list){
            if(cars.getId()==id){
                return cars;
            }
        }

        return null;
    }
}



