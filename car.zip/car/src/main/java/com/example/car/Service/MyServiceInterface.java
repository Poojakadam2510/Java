package com.example.car.Service;

import com.example.car.Cars;

import java.util.List;

public interface MyServiceInterface {

        public List<Cars> getCars();
        public Cars addCars(Cars cars);
        public Cars getByid(int id);
    }


