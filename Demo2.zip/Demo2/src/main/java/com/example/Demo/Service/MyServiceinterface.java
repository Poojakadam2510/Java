package com.example.Demo.Service;

import com.example.Demo.Books;

import java.util.List;

public interface MyServiceinterface {
    public List<Books> getBooks();
    public Books addBook(Books books);
    public Books getByid(int id);
}
