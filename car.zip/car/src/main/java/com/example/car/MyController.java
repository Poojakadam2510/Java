package com.example.car;

import com.example.car.Service.MyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyController {
    @Autowired
    MyService Myservice;
    @GetMapping("cars")
    public List<Cars> cars(){
        return Myservice.getCars();

    }

    @PostMapping("addcar")
    public Cars addCars(@RequestBody Cars cars){
        return Myservice.addCars(cars);
    }


    @GetMapping("carbyid")
    public Cars carByid(@RequestParam("id") int id){
        return Myservice.getByid(id);
    }

}

