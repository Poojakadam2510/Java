package com.example.car.config;

import com.example.car.Service.MyService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class config {
    @Bean
    public MyService Myservice(){
        return new MyService();
    }
}

