package com.example.Demo.Service;

import com.example.Demo.Books;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MyService implements MyServiceinterface{
    List<Books> list = new ArrayList<Books>();
    public MyService(){
        list.add( new Books(12,"java","about java"));
        list.add( new Books(13,"python","about python"));
    }

    @Override
    public List<Books> getBooks() {
        return null;
    }

    @Override
    public Books addBook(Books books) {
        this.list.add(books);
        return books;
    }

    @Override
    public Books getByid(int id) {
        for (Books books:this.list){
            if(books.getId()==id){
                return books;
            }
        }

        return null;
    }
}
