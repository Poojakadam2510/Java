package com.SpringExample.SpringClass;


public class Student {
    public String Studentname(){
        return "you are in student class inside studentname function";
    }
    public String Studentcollege(){
        return "you are in student class inside studentname function";
    }
}
