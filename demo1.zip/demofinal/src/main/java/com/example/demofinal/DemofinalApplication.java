package com.example.demofinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemofinalApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemofinalApplication.class, args);
    }

}
