package com.example.demo.Controller;

import com.example.demo.Model.UserModel;
import com.example.demo.Model.Userdetails;
import com.example.demo.Repoistory.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.SQLException;

@Controller
public class Controllers {

    @Autowired
    UserModel userModel;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/index")
    public String index(){
        return "index";
    }
    @GetMapping("/About")
    public String about(){
        return "About";
    }
    @GetMapping("/account")
    public String account(){
        return "account";
    }
    @GetMapping("/contact")
    public String contact(){
        return "contact";
    }
    @GetMapping("/detail")
    public String details(){
        return "detail";
    }
    @GetMapping("/success")
    public String success(){
        return "success";
    }
    @GetMapping("/welcome")
    public String welcome(){
        return "welcome";
    }

    @RequestMapping("/save")
    public String save(@ModelAttribute("Users") Userdetails userdetails) throws ClassNotFoundException, SQLException {
        System.out.println(userdetails.id);
        System.out.println(userdetails.username);
        System.out.println(userdetails.password);
        userModel.insert(userdetails);
        return "success";
    }
}
