package com.SpringExample.SpringClass;


import org.springframework.stereotype.Component;

@Component
public class Demo {
    public Demo(){

    }
    public  String demoin(){
        return "you'r  in demo class";
    }

}
