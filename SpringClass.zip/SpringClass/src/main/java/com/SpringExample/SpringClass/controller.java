package com.SpringExample.SpringClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



public class controller {

    @Autowired
    Student student;
    @Autowired
    College college;
    @Autowired
    Demo demo;

    @RequestMapping("/")
    public String home() {
        return "Hello World!";
    }
    @RequestMapping(value="/studentname")
        public String name(){

            return student.Studentname();
        }
    @RequestMapping(value="/collegename")
    public String collegename(){

        return College.collegename();

    }
    @RequestMapping(value="/about")
    public String about(){
        return "you are in about page";
    }
    @RequestMapping(value = "calculation")
    public int cal(){
            return  4;
    }
      @GetMapping(value = "home")
    public void getmap(){

      }
      @GetMapping(value = "/post")
              public String post(){
          return "post";
      }


    }

